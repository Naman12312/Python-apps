from setuptools import setup
setup(name = "Calac", 
version="0.2",
description = "This is a calculator",
long_description="This is a calculator",
author = "Naman",
packages = ["Calac"],
install_requires = [],
)